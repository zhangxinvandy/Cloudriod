<template lang="pug">
  .app-container
    //- el-form
    //-   el-form-item(label='Search Reports')
    //-     el-input(v-model='searchQuery' @input='debounceSearch')
    el-table(:data='reportsFiltered' empty-text='No data' v-loading='loading')
      el-table-column(prop='submission' label='ID' sortable)
      el-table-column(prop='title' label='Title')
      el-table-column(label='Status')
        template(slot-scope='scope')
          el-tag(type='success') complete
      el-table-column(label='Uploaded')
        template(slot-scope='scope') {{new Date(scope.row.eval_start_time) | timeAgo}}
      el-table-column(prop='eval_end_time' label='Finished')
        template(slot-scope='scope') {{new Date(scope.row.eval_end_time) | timeAgo}}
      el-table-column(fixed='right')
        template(slot='header' slot-scope='scope')
          el-input(v-model='query' size='mini' placeholder='Type to search')
        template(slot-scope='scope')
          router-link(:to="{ path: '/reports/content/' + scope.row.submission }")
            el-button(type='primary' size='small' plain)
              | View
</template>

<script>
import { timeAgo, code2Status } from '@/filters'
import _ from 'lodash'

export default {
  name: 'Documentation',
  data() {
    return {
      reports: [],
      query: '',
      searchQuery: '',
      loading: false
    }
  },
  methods: {
    fetchReports: _.debounce(async (query) => {
      this.loading = true
      const res = fetch(`/api/reports?search=${query}`)
      const json = await res.json()
      this.loading = false
      this.reports = data.results
    }),
    debounceSearch (e) {
      this.fetchReports(e)
    }
  },
  computed: {
    reportsFiltered() {
      // FIXME: filter is not well implemented
      return this.reports.filter(item => !this.query ||
        JSON.stringify(item).toLowerCase().includes(this.query.toLowerCase()))
    }
  },
  async mounted() {
    this.loading = true
    const response = await fetch('/api/reports')
    const data = await response.json()
    this.loading = false
    console.log(data)
    this.reports = data.results
    // .filter(item => {
    //   item.eval_start_time = item.eval_start_time.substring(0, 19).replace('T', ' ')
    //   item.eval_end_time = item.eval_end_time.substring(0, 19).replace('T', ' ')
    //   return item
    // })
  }
}
</script>

<style lang="scss" scoped>
.documentation-container {
  margin: 50px;
  display: flex;
  flex-wrap: wrap;
  .document-btn {
    margin-left: 50px;
    display: block;
    cursor: pointer;
    background: black;
    color: white;
    height: 60px;
    width: 200px;
    margin-bottom: 16px;
    line-height: 60px;
    font-size: 20px;
    text-align: center;
  }
}
</style>
