<template lang="pug">
  .report-panel
    h3(class='header') Flowdroid Report \#{{id}}
    el-steps(:active='activeIndex' :space="200" :finish-status='finishStatus' style='margin: 1em 0')
      el-step(title='Uploaded' :description='startTimeAgo')
      el-step(title='In Progress')
      el-step(title='Complete' :description='finishTimeAgo')
    el-tabs(type="border-card")
      el-tab-pane(label='Results')
        el-table(v-if="data.length" :data='data' style="width: 100%")
          el-table-column(type='expand')
            template(slot-scope='props')
              el-form(v-for='(source, idx) in props.row.sources' label-position='left' inline)
                el-form-item(label='Source Method')
                  prism(language='java' :code='source["@Method"]' style='font-size: 0.8rem')
                el-form-item(label=`Source Statement`)
                  prism(language='java' :code='source["@Statement"]' style='font-size: 0.8rem')
                el-form-item(v-if='source["AccessPath"]' label='Taint SubFields')
                  prism(language='java' :code='source["AccessPath"]["@TaintSubFields"].toString()' style='font-size: 0.8rem')
                el-form-item(v-if='source["AccessPath"]' label='Access Path Type')
                  prism(language='java' :code='source["AccessPath"]["@Type"]' style='font-size: 0.8rem')
                el-form-item(v-if='source["AccessPath"]' label='Access Path Value')
                  prism(language='java' :code='source["AccessPath"]["@Value"]' style='font-size: 0.8rem')
                el-divider
          el-table-column(label='Sink Method')
            template(slot-scope='scope')
              prism(language='java' :code='scope.row.sinkMethod' style='font-size: 0.8rem')
          el-table-column(label='Sink Statement')
            template(slot-scope='scope')
              prism(language='java' :code='scope.row.sinkStmt' style='font-size: 0.8rem')
        p(v-else) FlowDroid found no sources and sinks.
      el-tab-pane(label='XML')
        prism(language='xml' :code='reportXMLRaw' style='font-size: 0.8rem')
      el-tab-pane(label='JSON')
        prism(language='json' :code='reportJsonRaw' style='font-size: 0.8rem')
</template>

<script>
import Prism from 'vue-prismjs'
import format from 'xml-formatter'
import 'prismjs/themes/prism.css'
import { timeAgo } from '@/filters'

export default {
  name: 'ReportPanel',
  components: {
    Prism
  },

  props: {
    reportJson: {
      type: Object,
      default: () => {}
    },
    reportXml: {
      type: String,
      default: ''
    },
    startTime: {
      default: ''
    },
    finishTime: {
      default: ''
    },
    id: {
      default: 0
    },
    status: {
      Type: String,
      default: ''
    }
  },

  data() {
    return {
      defaultProps: {
        children: '',
        label: ''
      }
    }
  },

  computed: {
    activeIndex() {
      return this.status === 'RDY' ? 3 : 2
    },
    finishStatus() {
      switch (this.status) {
        case 'RDY':
          return 'success'
        default:
          return 'info'
      }
    },
    data() {
      if (!this.reportJson['Results']) {
        return []
      }
      const results = this.reportJson['Results']['Result']
      return results.map(item => {
        // item.sinkType = item['Sink']['AccessPath']['@Type']
        // item.sinkValue = item['Sink']['AccessPath']['@Value']
        return {
          sinkMethod: item['Sink']['@Method'].replace(': ', ':\n  ').replace('<', '').replace('>', ''),
          sinkStmt: item['Sink']['@Statement'],
          sources: item['Sources']['Source']
        }
      })
    },
    reportXMLRaw() {
      return format(this.reportXml, {
        indentation: '  '
      })
    },
    reportJsonRaw() {
      return JSON.stringify(this.reportJson)
    },
    startTimeAgo() {
      return timeAgo(new Date(this.startTime))
    },
    finishTimeAgo() {
      return timeAgo(new Date(this.finishTime))
    }
  }
}
</script>

<style scoped>
.header {
  margin-bottom: .75em;
}
</style>
<style>
.el-form-item__content > pre {
  margin: 0;
  padding: 0 1em 0 1em;
  line-height: 36px;
}
</style>