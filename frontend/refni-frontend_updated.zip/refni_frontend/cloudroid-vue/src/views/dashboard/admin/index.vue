<template lang="pug">
.dashboard-editor-container
  //- github-corner.github-corner
  //- panel-group(@handlesetlinechartdata='handleSetLineChartData')
  //- el-row(style='padding:16px;margin-bottom:32px;')
  el-card(class="box-card")
    el-form(ref='form' :model='form' :rules='rules')
      el-upload(drag action='/api/submissions/' class='upload-box' :on-remove='handleRemove' multiple name='attachment' :on-error='onUploadError' :on-success='onUploadSuccess' :auto-upload="false" :on-change='onUploadFileChange' v-loading='uploading')
        i(class='el-icon-upload')
        .el-upload__text
          | Drop files here or
          em  click to upload
        .el-upload__tip(slot='tip') apk files with a size less than 100MB
      el-form-item(label='Email' prop='email')
        el-input(v-model='form.email')
      el-form-item
        el-button(type='primary' @click='onSubmit' :disabled='files.length==0' :loading="uploading") Upload
  //- el-row(v-if='reportRaw' style='background:#fff;padding:16px;margin-bottom:32px;')
  //-   report-panel(:report-xml='reportRaw' :report-json='reportRaw')
  el-card(class="box-card")
    el-table(:data='submissionsRendered' empty-text='No data' v-loading="loading")
        el-table-column(prop='id' label='ID' sortable width='60')
        el-table-column(label='Status' width='105')
          template(slot-scope='scope')
            el-tag(:type='scope.row.statusCode') {{ scope.row.status | code2Status }}
        el-table-column(prop='attachment' label='Attachment')
        el-table-column(label='Uploaded')
          template(slot-scope='scope') {{ new Date(scope.row.created) | timeAgo }}
        //- el-table-column(prop='eval_end_time' label='Finished')
        //-   template(slot-scope='scope') {{new Date(scope.row.eval_end_time) | timeAgo}}
        el-table-column(label='User')
          template(slot-scope='scope') {{ scope.row.user.email }}
        el-table-column(fixed='right')
          template(slot='header' slot-scope='scope')
            el-input(v-model='query' size='mini' placeholder='Type to search')
          template(slot-scope='scope')
            router-link(:to="{ path: '/reports/content/' + scope.row.id }")
              el-button(type='primary' plain size='small')
                | View
    el-pagination(layout="prev, pager, next" :total="count" :current-page.sync='currPage' @current-change='currChange')
</template>

<script>
import GithubCorner from '@/components/GithubCorner'
import PanelGroup from './components/PanelGroup'
import BoxCard from './components/BoxCard'
import Dropzone from '@/components/Dropzone'
import ReportPanel from '@/components/Report'
import { code2Status, code2STCode } from '@/filters'
import schema from 'async-validator'

const lineChartData = {
  newVisitis: {
    expectedData: [100, 120, 161, 134, 105, 160, 165],
    actualData: [120, 82, 91, 154, 162, 140, 145]
  },
  messages: {
    expectedData: [200, 192, 120, 144, 160, 130, 140],
    actualData: [180, 160, 151, 106, 145, 150, 130]
  },
  purchases: {
    expectedData: [80, 100, 121, 104, 105, 90, 100],
    actualData: [120, 90, 100, 138, 142, 130, 130]
  },
  shoppings: {
    expectedData: [130, 140, 141, 142, 145, 150, 160],
    actualData: [120, 82, 91, 154, 162, 140, 130]
  }
}

export default {
  name: 'DashboardAdmin',
  components: {
    GithubCorner,
    PanelGroup,
    BoxCard,
    Dropzone,
    ReportPanel
  },
  data() {
    return {
      rules: {
        email: [
          {
            required: true,
            message: 'Please provide a valid email',
            trigger: 'blur',
            type: 'email'
            // pattern: schema.pattern.email
          }
        ]
      },
      uploading: false,
      form: {
        email: '',
      },
      files: [],
      uploadData: {
        'user.email': 'yahuis@gmail.com',
        type: 'FU',
        repo: ''
      },
      reportRaw: {},
      count: 0,
      currPage: 1,
      query: '',
      submissions: [],
      loading: false,
      lastUploadId: 0
    }
  },
  methods: {
    onUploadFileChange(file, files) {
      this.files = files
    },
    async onSubmit() {
      const data = new FormData()
      data.append('user.email', this.form.email)
      data.append('type', 'FU')
      data.append('repo', '')
      data.append('attachment', this.files[0].raw)
      this.uploading = true
      const res = await fetch('/api/submissions/', {
        method: 'POST',
        headers: {
          // 'Content-Type': 'application/json'
        },
        body: data
      })
      const json = await res.json()
      this.uploading = false
      console.log(json)
      if (res.status == 200 || res.status == 201) {
        this.$message({
          message: 'Uploaded',
          type: 'success'
        })
        this.currChange(1)

      } else {
        if (json['attachment'])
          this.$message({
            message: json['attachment'][0],
            type: 'error'
          })
      }
    },
    async currChange(pageNum) {
      this.loading = true
      const res = await fetch(`/api/submissions?page=${pageNum}`)
      const json = await res.json()
      this.loading = false
      console.log(json)
      this.submissions = json.results
    },
    handleSetLineChartData(type) {
      this.lineChartData = lineChartData[type]
    },
    dropzoneS(file) {
      console.log(file)
      this.$message({ message: 'Upload success', type: 'success' })
    },
    dropzoneR(file) {
      console.log(file)
      this.$message({ message: 'Delete success', type: 'success' })
    },
    handleRemove(f, files) {
      console.log(f, files)
    },
    onUploadError(err) {
      console.log(err)
      this.$message({ message: err, type: 'error' })
    },
    onUploadSuccess(res) {
      console.log(res)
      this.$message({
        message: 'Successfully uploaded',
        type: 'success'
      })
      this.lastUploadId = res.id
    }
  },
  computed: {
    submissionsRendered() {
      return this.submissions.map(item => {
        item.statusCode = code2STCode(item.status)
        return item
      }).filter(item => !this.query ||
        JSON.stringify(item).toLowerCase().includes(this.query.toLowerCase()))
    }
  },
  async mounted() {
    console.log(schema)
    this.loading = true
    const res = await fetch('/api/submissions')
    const json = await res.json()
    this.loading = false
    console.log(json)
    this.submissions = json.results
    this.count = json.count
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  // background-color: rgb(240, 242, 245);
  position: relative;

  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }
}

.upload-box {
  i {
    font-size: 2.5em;
    color: #304156;
  }
  width: 100%;
  height: 100%;
  // border: #ccc dashed 1px;
  // border-radius: 8px;
  // padding: 12px;
  em {
    color: #42b983;
    font-style: normal;
  }
}

.upload-box:hover {
  border-color: #42b983;
}

@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
<style>
.el-upload {
  width: 100%;
}
.el-upload-dragger {
  width: 100%;
}
</style>
