<template lang="pug">
  el-card(class='box-card')
    ReportPanel(:report-json='json' :report-xml='xml' :start-time='startTime' :finish-time='endTime' :id='id' :status='status')
</template>

<script>
import ReportPanel from '@/components/Report'

export default {
  name: 'ReportDetail',
  components: {
    ReportPanel
  },
  data() {
    return {
      xml: '',
      json: {},
      startTime: '',
      endTime: '',
      status: 'uploaded'
    }
  },
  computed: {
    id() {
      return this.$route.params.id
    }
  },
  async mounted() {
    const id = this.id
    const getContentByType = async(type) => {
      const res = await fetch(`/api/submissions/getReportBySubmissionID/?sid=${id}&type=${type}`)
      const json = await res.json()
      console.log(json)
      return json
    }
    const { status, report } = await getContentByType('json')
    const { content, eval_start_time, eval_end_time } = report
    this.status = status
    this.startTime = eval_start_time
    this.endTime = eval_end_time
    const result = JSON.parse(content)
    this.json = result['DataFlowResults']
    const xmlData = await getContentByType('xml')
    this.xml = xmlData.report.content
  }
}
</script>
