<template>
  <div class="app-container">
    <aside>
     Welcome to Cloudroid Web Application!<br>
     Cloudroid is a platform which can analyze apk files and automatically generate analysis report.<br>
    <!-- </aside> -->
    <!-- <aside> -->
     You can use Cloudroid easily in the following three steps:<br>
     (1) Go to Cloudroid home page and upload your apk files.<br>
    <!-- </aside> -->
     <img src="../../assets/Picture1.jpg" width='60%' height='40%' alt='picture1' ><br>
     <!-- <aside> -->
     (2) After the apk files are uploaded, the backend analysis tools will begin analyze your apk files.<br>
     <!-- </aside> -->
     <img src="../../assets/Picture2.jpg" width='60%' height='40%' alt='picture1' ><br>
     <!-- <aside> -->
     (3) After the analysis completes, you can download the analysis report from report list page.<br>
    <!-- </aside> -->
    <img src="../../assets/Picture3.jpg" width='60%' height='40%' alt='picture1' ><br>
    <!-- <aside> -->
      Enjoy yourself with Cloudroid!
    </aside>
    <!-- <el-button icon="el-icon-question" type="primary" @click.prevent.stop="guide">
      Show Guide
    </el-button> -->
  </div>
</template>

<script>
import Driver from 'driver.js' // import driver.js
import 'driver.js/dist/driver.min.css' // import driver.js css
import steps from './steps'

export default {
  name: 'Guide',
  data() {
    return {
      driver: null
    }
  },
  mounted() {
    this.driver = new Driver()
  },
  methods: {
    guide() {
      this.driver.defineSteps(steps)
      this.driver.start()
    }
  }
}
</script>
