
<template>
  <div>
    <p>Please provide your comments for our APP</p>
    <p>----------------------------------------------------------------------------------------------------------------------</p>
    <p />
    <!-- input title: trim  -->
    The title of your comments
    <p></p>
    <p />
    <input v-model.trim="inputContent" placeholder=" The tile  ... " />
    {{ inputContent }}
    <p></p>
    <p />Detailed comments
    <p></p>
    <p />
    <textarea v-model="textarea" placeholder="The comments ... "></textarea>
    {{ textarea }}
    <p>----------------------------------------------------------------------------------------------------------------------</p>
    <p />
    <p>Which functions would you recommend：</p>
    <p>
      <input type="checkbox" value="UI" v-model="checkedNames" />
      <label>More beautiful UI</label>
    </p>
    <p />
    <p>
      <input type="checkbox" value="Android" v-model="checkedNames" />
      <label>Better Android APP analysis</label>
    </p>
    <p />
    <p>
      <input type="checkbox" value="Other APP" v-model="checkedNames" />
      <label>Support Other APP analysis</label>
    </p>
    <p />
    <br />
    <span>You select: {{ checkedNames }}</span>
    <p>----------------------------------------------------------------------------------------------------------------------</p>
    <p />
    <p>Where do you usually obtain your Android APP</p>
    <p>
      <input type="radio" value="Google" v-model="picked" />
      <label>Google Play</label>
    </p>
    <p />
    <p>
      <input type="radio" value="APP web" v-model="picked" />
      <label>Official Webesite</label>
    </p>
    <p />
    <p>
      <input type="radio" value="Other" v-model="picked" />
      <label>Other Source</label>
    </p>
    <p />
    <span>You picked: {{ picked }}</span>
    <p>----------------------------------------------------------------------------------------------------------------------</p>
    <p />
    <div id="app1">
      <select v-model="selected">
        <option value>---Select Your rating for our APP (0-5)---</option>
        <option value="0:Very Bad">0:Very Bad</option>
        <option value="1:Very Bad">1:Very Bad</option>
        <option value="2:Just OK">2:Just OK</option>
        <option value="3:Looks Good">3:Looks Good</option>
        <option value="4:Pretty Good">4:Pretty Good</option>
        <option value="5:Very Good">5:Very Good</option>
      </select>
      <br />
      <br />
      <div id="output">You select: {{selected}}</div>
    </div>
    <p>----------------------------------------------------------------------------------------------------------------------</p>
    <p />
    <div id="app">
      <!-- `greet`  -->
      <button @click="submit">Submit</button>
    </div>
  </div>
</template>
<script type="text/javascript">
export default {
  data() {
    return {
      selected: '',
      picked: '',
      checked: false,
      checkedNames: [],
      inputContent: '',
      textarea: ''
    }
  }
}

</script>
