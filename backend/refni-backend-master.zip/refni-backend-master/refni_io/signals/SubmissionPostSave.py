from refni_io.tasks import dispatch_submission_celery


def dispatch_user_submission(sender, **kwargs):
    sub = kwargs['instance']
    print('signal: triggered')
    dispatch_submission_celery.delay(sub.id)

