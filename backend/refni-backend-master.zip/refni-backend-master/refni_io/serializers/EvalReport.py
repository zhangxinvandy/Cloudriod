from rest_framework import serializers
from django.db import transaction
from refni_io.models.Submission import Submission
from refni_io.models.EvalReport import EvalReport
from xmljson import badgerfish as bf
from xml.etree.ElementTree import fromstring
import json
from pytz import timezone


# All fields read only.
class EvalReportSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    title = serializers.CharField(read_only=True)
    content = serializers.JSONField(read_only=True)
    xmlcontent = serializers.FileField(allow_null=False, allow_empty_file=False, use_url=False)
    submission = serializers.PrimaryKeyRelatedField(queryset=Submission.objects.all(), many=False)
    eval_start_time = serializers.DateTimeField(read_only=True, default_timezone=timezone('America/Chicago'))
    eval_end_time = serializers.DateTimeField(read_only=True, default_timezone=timezone('America/Chicago'))

    def validate_submission(self, value):
        if EvalReport.objects.filter(submission=value).exists():
            raise serializers.ValidationError('The result for this submission has already been uploaded.')
        return value

    def validate_xmlcontent(self, value):
        try:
            bf.data(fromstring(value.read()))
            value.seek(0, 0)
        except:
            raise serializers.ValidationError('XML file corrupted')
        return value

    # NOT USED, READ ONLY
    @transaction.atomic
    def create(self, validated_data):
        xmlfilecontent = validated_data['xmlcontent'].read()
        jsoncontent = json.dumps(bf.data(fromstring(xmlfilecontent)))
        return EvalReport.objects.create(content=jsoncontent, **validated_data)

    def update(self, instance, validated_data):
        pass

