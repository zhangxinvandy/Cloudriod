from refni_backend.celery import *
from refni_io.models.Submission import Submission
from refni_io.models.EvalReport import EvalReport
import datetime
import requests


@app.task
def dispatch_submission_celery(sid):
    # Here do the real dispatching
    print(sid, 'DISPATCHING TO ANALYZER')
    sub = Submission.objects.get(id=sid)
    dispatch_submission(sub)


def dispatch_submission(sub):
    sid = sub.id
    start_time = datetime.datetime.now()

    # Send to analyzer client
    file = str(sub.attachment)
    data = '{"url": "s3://apktestbucket/%s"}' % (file,)
    print(file, data)
    headers = { 'Content-Type': 'application/json', }
    r = requests.post('http://35.202.55.38:5000', headers=headers, data=data)
    if r.status_code != 200:
        print('ERROR when submitting %d: %s' % (sid, r.reason))
        sub.mark_error()
    else:
        end_time = datetime.datetime.now()
        original_text = r.text
        # jsontext = json.dumps(bf.data(fromstring(original_text)))
        data = {'submission': sub,
                'content': original_text,
                'xmlcontent': None,
                'eval_start_time': start_time,
                'eval_end_time': end_time
                }
        EvalReport.objects.create(**data)

        sub.mark_ready()

