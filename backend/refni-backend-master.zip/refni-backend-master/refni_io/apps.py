from django.apps import AppConfig


class RefniIoConfig(AppConfig):
    name = 'refni_io'

    def ready(self):
        from django.db.models.signals import post_save
        from refni_io.signals.SubmissionPostSave import dispatch_user_submission

        print('Connecting signals')
        post_save.connect(dispatch_user_submission, sender='refni_io.Submission', dispatch_uid='refni_io_file_submission')

