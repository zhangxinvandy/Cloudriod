from django.apps import AppConfig


class RefniServiceConfig(AppConfig):
    name = 'refni_service'
