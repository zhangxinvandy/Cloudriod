from refni_io.serializers.Submission import SubmissionSerializer
from refni_io.models.Submission import Submission
from refni_io.models.EvalReport import EvalReport
from refni_io.serializers.EvalReport import EvalReportSerializer
from rest_framework import viewsets
from rest_framework import permissions
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.core.exceptions import ObjectDoesNotExist
import json
from xmljson import badgerfish as bf
from xml.etree.ElementTree import fromstring


class SubmissionViewSet(viewsets.ModelViewSet):
    queryset = Submission.objects.all().order_by('-created')
    serializer_class = SubmissionSerializer
    # permission_classes = (permissions.DjangoModelPermissions, )

    @action(detail=False, methods=['GET'])
    def getReportBySubmissionID(self, request, format=None):
        sid = self.request.query_params.get('sid', None)
        try:
            if sid is not None:
                type = self.request.query_params.get('type', 'xml')
                sid = int(sid)
                report = EvalReport.objects.get(submission=sid)
                st = report.submission.status
                serializer = EvalReportSerializer(report)
                data = serializer.data

                if type == 'json':
                    data['content'] = json.dumps(bf.data(fromstring(data['content'])), indent=2)

                return Response({'status': st, 'report': data})
            return Response({'error': 'please include an sid parameter: ?sid='}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError:
            return Response({'error': 'sid is not an integer'}, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist:
            queryset = Submission.objects.all()
            sub = get_object_or_404(queryset, pk=sid)
            return Response({'status': sub.status, 'report': None})

