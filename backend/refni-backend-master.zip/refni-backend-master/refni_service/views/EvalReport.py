from refni_io.serializers.EvalReport import EvalReportSerializer
from refni_io.models.EvalReport import EvalReport
from rest_framework import viewsets
from rest_framework import permissions
from rest_framework import status
from rest_framework import filters
from rest_framework.response import Response
from rest_framework import mixins
from django_filters.rest_framework import DjangoFilterBackend
from xmljson import badgerfish as bf
from xml.etree.ElementTree import fromstring
import json
import django_filters.rest_framework


class EvalReportViewSet(
        mixins.ListModelMixin,
        mixins.RetrieveModelMixin,
        viewsets.GenericViewSet):
    queryset = EvalReport.objects.all()
    serializer_class = EvalReportSerializer
    # permission_classes = (permissions.DjangoModelPermissions, )
    # filter_backends = [filters.SearchFilter]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    search_fields = ['content']

    def retrieve(self, request, pk=None):
        obj = self.queryset.filter(pk=pk).get()
        serializer = self.serializer_class(obj)
        data = serializer.data
        query_type = request.query_params.get('type', 'xml')
        if query_type == 'xml':
            return Response(data)
        elif query_type == 'json':
            data['content'] = json.dumps(bf.data(fromstring(data['content'])), indent=2)
            return Response(data)
        else:
            return Response({'error': 'Unknown type: ' + query_type}, status=status.HTTP_400_BAD_REQUEST)

    class Meta:
        ordering = ['-id']

