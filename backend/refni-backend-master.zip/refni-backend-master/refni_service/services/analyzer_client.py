from refni_backend.settings.development import *


# This class defines the connector to analyzer.
class AnalyzerClient:
    def __init__(self):
        # Place everything you need to connect to your analyzing service 
        # Settings are placed in refni_backend/settings/development.py or production.py
        # 
        pass
    
    def send(self, sub):
        pass
