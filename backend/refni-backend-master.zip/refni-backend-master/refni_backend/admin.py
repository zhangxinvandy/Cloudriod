from django.contrib import admin
from refni_io.models.Submission import Submission

# Register your models here.
admin.site.register(Submission)
