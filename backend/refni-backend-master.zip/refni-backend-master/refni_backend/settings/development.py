# Any dev settings can be placed here
from refni_backend.settings.base import *


DEBUG = True

ALLOWED_HOSTS = []

# DB_SERVER_ADDRESS = '127.0.0.1'
DB_SERVER_ADDRESS = 'mongodb+srv://refni-ugp06.mongodb.net/test'
GOOGLE_CLOUD_STORAGE = 'cloudroid_public'
CELERY_BROKER_ADDRESS = 'amqp://127.0.0.1'

DATABASES = {
    'default': {
        'ENGINE': 'djongo',
        'NAME': 'refni',
        'HOST': DB_SERVER_ADDRESS,
        'USER': 'ClouDroid',
        'PASSWORD': 'WeAreAllOnThe4thFloor'
    }
}

# FULL PATH to the folder where you store uploaded files (WE'RE NOT SAVING FILES LOCALLY!)
# MEDIA_ROOT = os.path.join(BASE_DIR, 'uploaded_files')

# Default file storage engine
# DEFAULT_FILE_STORAGE = 'storages.backends.gcloud.GoogleCloudStorage'
DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
# GS_BUCKET_NAME = GOOGLE_CLOUD_STORAGE
AWS_ACCESS_KEY_ID = 'AKIAWSXP2FPBQPKIEN73'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'apktestbucket'
AWS_DEFAULT_ACL = 'private'

# Debug only. DO NOT USE ALLOW_ALL in production.
CORS_ORIGIN_ALLOW_ALL = True
