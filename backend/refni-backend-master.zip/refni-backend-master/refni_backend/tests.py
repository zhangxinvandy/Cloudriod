from django.test import TestCase
from refni_io.models.Submission import Submission
from refni_io.models.EvalReport import EvalReport
from refni_io.serializers.EvalReport import EvalReportSerializer


# Create your tests here.
class SubmissionTestCase(TestCase):
    def setUp(self):
        EvalReport.objects.create(title='title')

    def test_submission_exists(self):
        s = EvalReport.objects.get(title='title')
        self.assertEqual(s.title, 'title')


class SerializerTestCase(TestCase):
    def setUp(self):
        EvalReport.objects.create(title='title')

    def test_serializer_works(self):
        rp = EvalReport.objects.get(title='title')
        s = EvalReportSerializer(rp)
        self.assertEqual(s.data['title'], 'title')

