from django.apps import AppConfig


class RefniBackendConfig(AppConfig):
    name = 'refni_backend'
