# refni-backend

This is the course project for CSCE-606 software engineering.

## Run